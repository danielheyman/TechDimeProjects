$(function () {
	
	$('.faq-list').goFaq ();

});